#ifndef PRIME_HEADER
#define PRIME_HEADER

// Funkcie na zistovanie prvocisel
int isPrime(int x);
int nextPrime(int x);

#endif
