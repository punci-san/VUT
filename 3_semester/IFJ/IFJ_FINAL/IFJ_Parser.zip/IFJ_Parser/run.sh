#!/bin/sh

./ic18int Projekt.code
RETVAL=$?
[ $RETVAL -eq 0 ] && echo "\nSuccess"
[ $RETVAL -ne 0 ] && echo "\nFailure"
echo $RETVAL
