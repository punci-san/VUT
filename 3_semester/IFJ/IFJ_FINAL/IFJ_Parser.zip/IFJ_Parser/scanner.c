#include "scanner.h"
#include "str.h"
#include "err_code.h"

#include <ctype.h>
#include <stdlib.h>
#include <string.h>

#include <stdio.h>

FILE *file;

static char *keywords[KEYWORD_COUNT] =
{
  "def",
  "do",
  "else",
  "end",
  "if",
  "not",
  "nil",
  "then",
  "while"
};


int initScanner(char *filename)
{
  if ((file = fopen(filename,"r")) == NULL)
  {
    fprintf(stderr, "Problém pri otváraní súboru.\n");
    return FILE_ERROR;
  }
  return 0;
}

void freeScanner()
{
  fclose(file);
}

/*
  Ak token ktory sme obdrzali je keyword vratime poradove cislo keywordu v
  arrai, inac vratime TT_IDENTIFIKATOR
*/
static int isKeyword(String *token)
{
  for (int i = 0; i < KEYWORD_COUNT; i++)
  {
    // Ak je to niektory z keywordov vratime jeho ID
    if (strcmp(keywords[i],token->str) == 0)
    {
      return (24 + i); // 20 je pocet identifikatorov TokenType pred TokenType typu keywords
    }
  }
  return TT_IDENTIFIKATOR;
}

static int isSymbol(char ch,String *token)
{
  clearString(token);
  // Zobereme nasledujuci char
  char next_char = fgetc(file);

  // Pridame prvy char do stringu
  appendChar(ch,token);
  switch (ch)
  {
    case '=':
      // Ak prvy charakter je = moze za nim nasledovat =
      if (next_char == '=')
      {
        appendChar(next_char,token);
        return TT_EQUAL;
      }
      // Ak nie vratime naspat charakter do bufferu
      fseek(file,-1,SEEK_CUR);
      return TT_ASSIGNMENT;
    break;

    case '>':
      // Za > moze nasledovat =
      if (next_char == '=')
      {
        appendChar(next_char,token);
        return TT_HIGHER_EQUAL;
      }
      fseek(file,-1,SEEK_CUR);
      return TT_HIGHER;
    break;

    case '<':
      // Za < moze znova nasledovat =
      if (next_char == '=')
      {
        appendChar(next_char,token);
        return TT_LOWER_EQUAL;
      }
      fseek(file,-1,SEEK_CUR);
      return TT_LOWER;
    break;

    case '!':
      // Za ! moze nasledovat =
      if (next_char == '=')
      {
        appendChar(next_char,token);
        return TT_FALSE_EQUAL;
      }
      fseek(file,-1,SEEK_CUR);
      return TT_FALSE;
    break;

    case '(':
      fseek(file,-1,SEEK_CUR);
      return TT_LEFT_BRACKET;
    break;

    case ')':
      fseek(file,-1,SEEK_CUR);
      return TT_RIGHT_BRACKET;
    break;

    case ',':
      fseek(file,-1,SEEK_CUR);
      return TT_COMA;
    break;

    case '+':
      fseek(file,-1,SEEK_CUR);
      return TT_PLUS;
    break;

    case '-':
      fseek(file,-1,SEEK_CUR);
      return TT_MINUS;
    break;

    case '*':
      fseek(file,-1,SEEK_CUR);
      return TT_MULTIPLY;
    break;

    case '/':
      fseek(file,-1,SEEK_CUR);
      return TT_DIVISION;
    break;

    // AK sa vyskytol iny symbol tak to nepatri do nasho jazyka
    default:
      return -LEXICAL_ERR;
    break;
  }
  return -LEXICAL_ERR;
}
/*
  Vygeneruje z \ a dalsieho charakteru 1 escape_charakter
*/
char generateEscapeChar(char ch)
{
  switch (ch)
  {
    // Ak je \n
    case 'n':
      return '\012';
    break;

    // Ak je to \t
    case 't':
      return '\t';
    break;

    // Ak je to \"
    case '"':
      return '\042';
    break;

    // Ak je to \s medzera
    case 's':
      return ' ';
    break;

    // Ak je to \ tak jedna sa o lomitko
    case '\\':
      return '\134';
    break;

    case 'x':
      return 'x';
    break;

    default:
      return -LEXICAL_ERR;
    break;

  }
}

static int isHex(char ch)
{
  // Ak je to v intervale <0,9>
  if (ch >= 48 && ch <= 57)
  {
    // Vraciame cislo od 0 po 9
    return (ch - 48);
  }
  // Alebo ak je v intervale <A,F>
  else if (ch >= 'A' && ch <= 'F')
  {
    // Vraciame hodnotu od 10 po 15
    return (ch - 55);
  }
  // Alebo ak je v intervale <a,f>
  else if (ch >= 'a' && ch <= 'f')
  {
    // Vratime hodnotu od 10 po 15
    return (ch - 87);
  }
  // Ak je to v hocicom inom nie je to Hexadecimalne cislo
  else
  {
    return -1;
  }
}

int hexToChar()
{
  int hex = 0;
  char ch = fgetc(file);
  // Ak je mensie nez 0 nie je to hex a vraciame chybu
  if ((hex = isHex(ch)) < 0)
  {
    return -LEXICAL_ERR;
  }

  ch = fgetc(file);

  int tmp = 0;
  if ((tmp = isHex(ch)) < 0)
  {
    // Ak sa jedna iba o jeden charakter vratime jeden a posunieme sa o jedno dolava
    fseek(file,-1,SEEK_CUR);
    return hex;
  }

  // Obsahuje aj druhu hodnotu cize staru hodnotu vynasobime 16 aby sme posunuly o 1 desatinne miesto
  hex *= 16;

  hex += tmp;

  // Inac vraciame hexicalnu hodnotu
  return hex;
}

int getToken(String *token)
{
  typedef enum StateTypes
  {
    INIT,
    STRING,
    INTEGER,
    FLOAT,
    EXPONENT,
    COMMENT_LINE,
    COMMENT_BLOCK_START,
    COMMENT_BLOCK_END,
    COMMENT_BLOCK_END_ENTER,
    IDENTIFIER
  }StateTypes;

  StateTypes state = INIT;
  char ch;
  String *tmp;

  int hexalNumbers = 0;

  static int last_new_line = 2;

  last_new_line--;

  clearString(token);

  while(1)
  {
    ch = fgetc(file);
    switch (state)
    {

      default:
      case INIT:
        // Ak je koniec suboru
        if (ch == -1)
        {
          return TT_EOF;
        }

        // Ak mame end of line
        if (ch == EOL)
        {
          last_new_line = 2;
          return TT_EOL;
        }

        // Medzery ignorujeme
        if (ch == ' ')
        {
          continue;
        }

        // Je to cislo cize to moze byt but INTEGER alebo FLOAT
        if (isdigit(ch))
        {
          appendChar(ch,token);
          state = INTEGER;
          continue;
        }

        // Ak to zacina " znaci to zaciatok STRINGU
        if (ch == '"')
        {
          state = STRING;
          continue;
        }

        // Ak to zacina _ alebo malym charakterom je to identifikator
        if (ch == '_' || islower(ch))
        {
          appendChar(ch,token);
          state = IDENTIFIER;
          continue;
        }

        /*
          Urobime kontrolu ci je ked mame = tak za tym nasleduje begin
          Hladame =begin
        */
        if (ch == '=')
        {
          char next_char = fgetc(file);

          // Ak za = nasleduje b je pravdepodobne ze to moze byt =begin
          if (next_char == 'b')
          {
            appendChar(ch,token);
            appendChar(next_char,token);
            state = COMMENT_BLOCK_START;
            continue;
          }
          // Ak nie tak vratime spat ukazovatel o 2
          fseek(file,-1,SEEK_CUR);
        }

        // Ak to zacina # je to zaciatok riadkoveho komentara
        if (ch == '#')
        {
          state = COMMENT_LINE;
          continue;
        }

        // Posledna kontrola ci znak zadany je symbolom
        return isSymbol(ch,token);
      break;

      case STRING:
        if (ch == '"')
        {
          return TT_STRING;
        }
        else if (ch == EOL)
        {
          return -LEXICAL_ERR;
        }
        else if (ch == 92) // Lomeny charakter
        {
          // mame \ cize zobereme dalsi char
          char next_char = fgetc(file);
          // Ak nam vratilo naspat lomeny charakter jedna sa o chybu
          if((ch = generateEscapeChar(next_char)) == -LEXICAL_ERR)
          {
            return -LEXICAL_ERR;
          }
          if (ch == 'x')
          {
            char hexal;
            if ((hexal = hexToChar()) == -LEXICAL_ERR)
            {
              return -LEXICAL_ERR;
            }
            appendChar(hexal,token);
            continue;
          }

          // Pridame charakter
          //appendChar(ch,token);

          // Ak je to hexadecimalne cislo
          if (ch == 'x')
          {
            // Tak dalsie 2 nasledujuce musia byt
            hexalNumbers++;
            initString(&tmp);
            appendChar(ch,tmp);
            continue;
          }
        }
        appendChar(ch,token);
      break;

      case INTEGER:
        // Kontrola ci dalsi charakter je cislo
        if (isdigit(ch))
        {
          appendChar(ch,token);
          continue;
        }

        // Moze to byt exponent
        if (ch == 'e' || ch == 'E')
        {
          appendChar(ch,token);
          state = EXPONENT;
          continue;
        }

        /*
          Skontrolujeme ci zadany charakter nie je nahodou bodka
          co znaci float cize prepneme stav
        */
        if (ch == '.')
        {
          state = FLOAT;
          appendChar(ch,token);
          continue;
        }
        /*
          Ak je medzera alebo novy riadok, tak to znaci koniec ciselnej hodnoty,
          cize zmenime string na integer a vratime token
        */
        if (ch == ' ')
        {
          return TT_INTEGER;
        }

        // Ak je to novy riadok
        if (ch == EOL)
        {
          // Posunieme sa o jeden charakter
          fseek(file,-1,SEEK_CUR);
          return TT_INTEGER;
        }

        initString(&tmp);
        if (isSymbol(ch,tmp) != -LEXICAL_ERR)
        {
          fseek(file,-1,SEEK_CUR);
          freeString(tmp);
          return TT_INTEGER;
        }
        else
        {
          fseek(file,-1,SEEK_CUR);
          freeString(tmp);
          return -LEXICAL_ERR;
        }
      break;

      case FLOAT:
        // Kontrola ci dalsi charakter po "." je cislo
        if (isdigit(ch))
        {
          appendChar(ch,token);
          continue;
        }
        if (ch == 'e' || ch == 'E')
        {
          appendChar(ch,token);
          state = EXPONENT;
          continue;
        }
        /*
          Ak je medzera alebo novy riadok, tak to znaci koniec ciselnej hodnoty,
          cize vratime FLOAT identifikator
        */
        if (ch == ' ')
        {
          return TT_FLOAT;
        }

        if (ch == EOL)
        {
          fseek(file,-1,SEEK_CUR);
          return TT_FLOAT;
        }

        initString(&tmp);
        if (isSymbol(ch,tmp) != -LEXICAL_ERR)
        {
          fseek(file,-1,SEEK_CUR);
          freeString(tmp);
          return TT_FLOAT;
        }
        else
        {
          fseek(file,-1,SEEK_CUR);
          freeString(tmp);
          return -LEXICAL_ERR;
        }
      break;

      case EXPONENT:
        /*
          Exponent je definovany ako
          E[+/-]%d
        */
        if (ch == '+' || ch == '-')
        {
          if (charOccurances(token,ch) > 1)
          {
            return -LEXICAL_ERR;
          }
          appendChar(ch,token);
          continue;
        }
        if (isdigit(ch))
        {
          appendChar(ch,token);
          continue;
        }
        if (ch == ' ')
        {
          return TT_EXPONENT;
        }
        if (ch == EOL)
        {
          fseek(file,-1,SEEK_CUR);
          return TT_EXPONENT;
        }

        initString(&tmp);
        if (isSymbol(ch,tmp) != LEXICAL_ERR)
        {
          fseek(file,-1,SEEK_CUR);
          freeString(tmp);
          return TT_EXPONENT;
        }
        else
        {
          fseek(file,-1,SEEK_CUR);
          freeString(tmp);
          return -LEXICAL_ERR;
        }
      break;

      case COMMENT_LINE:
        // Cakame na koniec riadku vtedy koment konci
        if (ch == EOL)
        {
          state = INIT;
          fseek(file,-1,SEEK_CUR);
          continue;
        }
      break;

      case COMMENT_BLOCK_START:
        /*
          |=begin | = 7
          =b
          ^ Zatial mame toto co su 2 znaky a teraz musime dostat
          ostatne znaky =begin za ktorym nasleduje bude medzera alebo tabulator
        */
        // Je dlzka stringu 7 ?
        if (stringLength(token) == 7)
        {
          if (strcmp("=begin ",token->str) == 0 || strcmp("=begin\t",token->str) == 0)
          {
            if (last_new_line != 1)
            {
              // Uvolnime token a vratime error
              freeString(token);
              return -LEXICAL_ERR;
            }
            // Musime posunut ukazovatel bufferu o 1 dolava lebo terajsie CH nebolo spracovane
            fseek(file,-1,SEEK_CUR);
            state = COMMENT_BLOCK_END;
            clearString(token);
            continue;
          }
          //
          else if (strcmp("=begin\n",token->str) == 0)
          {
            if (last_new_line != 1)
            {
              // Uvolnime token a vratime error
              freeString(token);
              return -LEXICAL_ERR;
            }
            last_new_line = 2;
            // Musime posunut ukazovatel bufferu o 1 dolava lebo terajsie CH nebolo spracovane
            fseek(file,-1,SEEK_CUR);
            state = COMMENT_BLOCK_END;
            clearString(token);
            continue;
          }
          else
          {
            // Posunieme sa pred =
            fseek(file,-8,SEEK_CUR);

            // Ziskame =
            ch = fgetc(file);

            // Clearneme token
            clearString(token);

            // A vratime symbol
            return isSymbol(ch,token);
          }
        }
        else
        {
          appendChar(ch,token);
        }
      break;

      case COMMENT_BLOCK_END:
        /*
          Hladame =end pred ktorym je bud medzera alebo tabulator


        */
        // Natrafily sme skorej na EOF nez na =end
        if (ch < 0)
        {
          return -LEXICAL_ERR;
        }
        if (ch == '=')
        {
          char next_char = fgetc(file);
          if (next_char == 'e')
          {
            appendChar(ch,token);
            appendChar(next_char,token);
            continue;
          }
          fseek(file,-1,SEEK_CUR);
        }
        // |=end| = 4
        if (stringLength(token) == 5)
        {
          // AK sa token zhoduje z =end
          if (strcmp(token->str,"=end ") == 0 || strcmp(token->str,"=end\t") == 0)
          {
            // =end musi byt na zaciatku riadku
            if (last_new_line != 1)
            {
              // Ak neni uvolnime a ukoncime
              freeString(token);
              return -LEXICAL_ERR;
            }
            // Zmenime stav na COMMENT_BLOCK_END_ENTER
            state = COMMENT_BLOCK_END_ENTER;
            // Clearneme string
            clearString(token);
            // Skocime na zaciatok
            continue;
          // Ak sme nasli =end EOL tak mozme prepnut na stav INIT
          }
          else if (strcmp(token->str,"=end\n") == 0)
          {
            // Clearneme string
            clearString(token);
            // Zmenime stav
            state = INIT;
            // Povieme ze sme nasli enter
            last_new_line = 2;
            // Posunieme pointer
            fseek(file,-1,SEEK_CUR);
            // Skocime na zaciatok
            continue;
          }
          /*
            Ak sa string nerovna =end to znamena ze este sme nenasli koniec
            block komentaru preto vynulujeme string a hladame dalej
          */
          else
          {
            clearString(token);
            continue;
          }
        }
        else
        {
          // Kontrolujeme ci sme nasli zaciatocne =e ak hej tak az vtedy zaciname appendovat
          if (stringLength(token) > 0)
          {
            appendChar(ch,token);
          }
        }


      break;

      case COMMENT_BLOCK_END_ENTER:
        // Ignorujeme vsetko dokial nenajdeme enter
        if (ch == EOL)
        {
          // Zmenime stav na inicializaciu
          state = INIT;
          // Skocime na zaciatok
          continue;
        }
      break;

      case IDENTIFIER:
        /*
          IDENTIFIER sa moze skladat z pismen, cislic a _ a pri funkciach moze byt
          ukoncene ? alebo !
            state = INIT;
          ak nasleduje nieco ine vratime LEXICAL_ERR
        */

        // Alebo _ <a,z> <A,Z> <0,9>
        if (ch == '_' || isalnum(ch))
        {
          appendChar(ch,token);
          continue;
        }


        // medzera alebo novy riadok znaci ukoncenie identifikatoru
        if (ch == ' ')
        {
          return isKeyword(token);
        }

        if (ch == EOL)
        {
          fseek(file,-1,SEEK_CUR);
          return isKeyword(token);
        }
        // Ak ako posledny znak je ? alebo ! tak to ukoncuje identifikator
        if (ch == '?' || ch == '!')
        {
          appendChar(ch,token);
          return TT_FUN_IDENTIFIKATOR;
        }



        initString(&tmp);
        // Ak
        if (isSymbol(ch,tmp) != -LEXICAL_ERR)
        {
          freeString(tmp);
          fseek(file,-1,SEEK_CUR);
          return isKeyword(token);
        }
        else
        {
          freeString(tmp);
          return -LEXICAL_ERR;
        }
      break;
    }
  }
}
