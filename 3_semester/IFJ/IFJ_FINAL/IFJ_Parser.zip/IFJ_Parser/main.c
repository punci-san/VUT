#include <stdio.h>

#include "err_code.h"
#include "parser.h"
#include "generate_code.h"

int main(int argc, char **argv)
{
	// Ak nie je dobry pocet argumentov zadany je to error
	if (argc != 2)
	{
		fprintf(stderr, "Zadaný zlý počet argumentov\n");
		return LEXICAL_ERR;
	}

	// Error
	int err = 0;

	// Pokusime sa inicializovat scanner
	if ((err = initScanner(argv[1])) != 0)
	{
		return err;
	}

	// Nastavime nazov output filu
	if ((err = setGeneratedFile(argv[1])) != 0)
	{
		freeScanner();
		return err;
	}

	// Pokusime sa inicializovat parser
	if ((err = initParser()) != 0)
	{
		freeParser();
		freeScanner();
		freeGeneratedFile();
		return err;
	}

	// Zacneme parsovat subor
	err = Parse();

	// Uvolnime inicializovane struktury
	freeParser();
	freeScanner();
	freeGeneratedFile();

	printf("%d\n", err);

	return err;
}
