#!/bin/sh
RED=''
GREEN=''
NC=''

OK="${GREEN} OK ${NC}"
FAILED="${RED} FAILED ${NC}"

FILES="./tests/lexsynsem/*"
RUNTIMEFILES="./tests/runtimetests/*"
RUNTIMEFILESOUT="./tests/runtimeouts/"

# Compiler tests
for f in $FILES.src
do
  FILENAME=$(echo "$f" | sed "s/.*\///")
  RESULT=$(cat $f".out" | cut -b 1)
  ./main < $f > "${RUNTIMEFILESOUT}${FILENAME}.code"
  CMD_RESULT=$?
  if [ $CMD_RESULT -eq $RESULT ]
  then
    echo "${FILENAME} \t\t ${OK} ${CMD_RESULT}"
  else
    echo "${FILENAME} \t\t ${FAILED} ${CMD_RESULT}"
  fi
done

# Runtime tests
for f in $RUNTIMEFILES.src
do
  FILENAME=$(echo "$f" | sed "s/.*\///")
  RESULT=$(cat $f".out" | cut -b 1)
  ./main < $f > "${RUNTIMEFILESOUT}${FILENAME}.code"
  CMD_RESULT=$?
  if [ $CMD_RESULT -eq "0" ]
    then
    chmod 777 "${RUNTIMEFILESOUT}${FILENAME}.code"
    ./ic18int "${RUNTIMEFILESOUT}${FILENAME}.code"
    CMD_RESULT=$?
    if [ $CMD_RESULT -eq $RESULT ]
    then
      echo "${FILENAME} \t\t ${OK} ${CMD_RESULT}"
    else
      echo "${FILENAME} \t\t ${FAILED} ${CMD_RESULT}"
    fi
  else
    if [ $CMD_RESULT -eq $RESULT ]
    then
      echo "${FILENAME} \t\t ${OK} ${CMD_RESULT}"
    else
      echo "${FILENAME} \t\t ${FAILED} ${CMD_RESULT}"
    fi
  fi
done
