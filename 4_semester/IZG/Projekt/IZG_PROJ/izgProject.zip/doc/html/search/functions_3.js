var searchData=
[
  ['frustum_5fmat4',['frustum_Mat4',['../camera_8c.html#a9ae73100cfea5804280d19ffbafb7f07',1,'frustum_Mat4(Mat4 *const output, float const left, float const right, float const bottom, float const top, float const near, float const far):&#160;camera.c'],['../camera_8h.html#a9ae73100cfea5804280d19ffbafb7f07',1,'frustum_Mat4(Mat4 *const output, float const left, float const right, float const bottom, float const top, float const near, float const far):&#160;camera.c']]]
];
