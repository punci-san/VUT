var searchData=
[
  ['uniform',['uniform',['../structGPUUniforms.html#aa49800f649bb2566b817383b2fcac114',1,'GPUUniforms']]],
  ['uniforms',['uniforms',['../structGPUVertexShaderData.html#a0edb787d17cbca1ce03740b0a4296e0b',1,'GPUVertexShaderData::uniforms()'],['../structGPUFragmentShaderData.html#ad8271d982c7c798d1f617d9235a8bbf8',1,'GPUFragmentShaderData::uniforms()'],['../structGPUProgram.html#a707edbfaa82eb74936bfbb990c845706',1,'GPUProgram::uniforms()']]]
];
