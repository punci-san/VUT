var searchData=
[
  ['private_2eh',['private.h',['../stack_2src_2stack_2private_8h.html',1,'(Global Namespace)'],['../vector_2src_2vector_2private_8h.html',1,'(Global Namespace)']]]
];
