var searchData=
[
  ['reflect',['reflect',['../linearAlgebra_8c.html#a99d9fc7339bdd41ad0224926a11b4b2b',1,'reflect(Vec3 *const output, Vec3 const *const incident, Vec3 const *const normal):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a99d9fc7339bdd41ad0224926a11b4b2b',1,'reflect(Vec3 *const output, Vec3 const *const incident, Vec3 const *const normal):&#160;linearAlgebra.c']]],
  ['renderer',['renderer',['../structWindow.html#a2b52309ef359b6392454a3bb57398b5d',1,'Window']]],
  ['reserved',['reserved',['../structStack.html#a67852b957af50a592ef664150864b69d',1,'Stack::reserved()'],['../structVector.html#a94aac82cd99201901a1fd8e32cbdb1b0',1,'Vector::reserved()']]],
  ['rotate_5fmat4',['rotate_Mat4',['../linearAlgebra_8c.html#a07a5d933b90b3c5929a3a2a8e37405ba',1,'rotate_Mat4(Mat4 *const output, float const u, float const v, float const w, float const angle):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a07a5d933b90b3c5929a3a2a8e37405ba',1,'rotate_Mat4(Mat4 *const output, float const u, float const v, float const w, float const angle):&#160;linearAlgebra.c']]],
  ['runconformancetests',['runConformanceTests',['../structArguments.html#a6bc787170da38be26e99235d6f8183f9',1,'Arguments']]],
  ['running',['running',['../structWindow.html#a7e076f6f94c096513fa91d0588222993',1,'Window']]],
  ['runperformancetests',['runPerformanceTests',['../structArguments.html#a6b9b90f2db5d9b1feb0cf9ca6e6b3a18',1,'Arguments']]]
];
