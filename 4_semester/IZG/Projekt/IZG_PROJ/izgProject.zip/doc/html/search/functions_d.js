var searchData=
[
  ['translate_5fmat4',['translate_Mat4',['../linearAlgebra_8c.html#a4ea2f3b452065b47f0068eb9b4cc4ca9',1,'translate_Mat4(Mat4 *const output, float const tx, float const ty, float const tz):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a4ea2f3b452065b47f0068eb9b4cc4ca9',1,'translate_Mat4(Mat4 *const output, float const tx, float const ty, float const tz):&#160;linearAlgebra.c']]],
  ['transpose_5fmat4',['transpose_Mat4',['../linearAlgebra_8c.html#af2abaae108c4a9bfb7c97e96e0b929be',1,'transpose_Mat4(Mat4 *const output, Mat4 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#af2abaae108c4a9bfb7c97e96e0b929be',1,'transpose_Mat4(Mat4 *const output, Mat4 const *const input):&#160;linearAlgebra.c']]]
];
