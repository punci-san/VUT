var searchData=
[
  ['implementace_20vykreslovacího_20řetězce_20_2d_20vykreslování_20trojúhelníků',['Implementace vykreslovacího řetězce - vykreslování trojúhelníků',['../group__gpu__side.html',1,'']]],
  ['identity_5fmat4',['identity_Mat4',['../linearAlgebra_8c.html#abc0563608a098756d6628f85c5805bf6',1,'identity_Mat4(Mat4 *const output):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#abc0563608a098756d6628f85c5805bf6',1,'identity_Mat4(Mat4 *const output):&#160;linearAlgebra.c']]],
  ['idlecallback',['idleCallback',['../structWindow.html#aca8fcf0113fd079f5bc4050c1f72a93b',1,'Window']]],
  ['idlecallbackdata',['idleCallbackData',['../structWindow.html#a91eae2aff16e63ff29644aa0d287abb1',1,'Window']]],
  ['iffreeidexistreturn',['ifFreeIdExistReturn',['../cpu_8c.html#a994daae715d8bed25acde13d47ae39c2',1,'cpu.c']]],
  ['izg_20project_2e',['Izg project.',['../index.html',1,'']]],
  ['indextype',['IndexType',['../gpu_8h.html#a2bfb0a0ff1c379a8b4e8f9d24fdd4839',1,'IndexType():&#160;gpu.h'],['../gpu_8h.html#a86eb4663a9277131b889cd8829482527',1,'IndexType():&#160;gpu.h']]],
  ['indices',['indices',['../structGPUVertexPuller.html#a043bd88d5a8baa834418369b993a01b6',1,'GPUVertexPuller']]],
  ['infragment',['inFragment',['../structGPUFragmentShaderData.html#aa286b4180c0efb8593bbe0ecb8c6e60a',1,'GPUFragmentShaderData']]],
  ['init_5fvec2',['init_Vec2',['../linearAlgebra_8c.html#a2d4ebe1f775e16099a296626a20e944b',1,'init_Vec2(Vec2 *const target, float const x, float const y):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a2d4ebe1f775e16099a296626a20e944b',1,'init_Vec2(Vec2 *const target, float const x, float const y):&#160;linearAlgebra.c']]],
  ['init_5fvec3',['init_Vec3',['../linearAlgebra_8c.html#a898abc01a7905b120121d45afaba6635',1,'init_Vec3(Vec3 *const target, float const x, float const y, float const z):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a898abc01a7905b120121d45afaba6635',1,'init_Vec3(Vec3 *const target, float const x, float const y, float const z):&#160;linearAlgebra.c']]],
  ['init_5fvec4',['init_Vec4',['../linearAlgebra_8c.html#a68a9da6c0c100b70184cd882ace57195',1,'init_Vec4(Vec4 *const target, float const x, float const y, float const z, float const w):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a68a9da6c0c100b70184cd882ace57195',1,'init_Vec4(Vec4 *const target, float const x, float const y, float const z, float const w):&#160;linearAlgebra.c']]],
  ['initglobals',['initGlobals',['../globals_8c.html#af3e2e485f3ff008910d925cbb25f3a73',1,'initGlobals():&#160;globals.c'],['../globals_8h.html#af3e2e485f3ff008910d925cbb25f3a73',1,'initGlobals():&#160;globals.c']]],
  ['invert_5fmat4',['invert_Mat4',['../linearAlgebra_8c.html#a0fc538e9cc74cb89e12dfb6434fb53fd',1,'invert_Mat4(Mat4 *const output, Mat4 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a0fc538e9cc74cb89e12dfb6434fb53fd',1,'invert_Mat4(Mat4 *const output, Mat4 const *const input):&#160;linearAlgebra.c']]],
  ['invertex',['inVertex',['../structGPUVertexShaderData.html#a5744e11986f6ac290817370ed6b45726',1,'GPUVertexShaderData']]]
];
