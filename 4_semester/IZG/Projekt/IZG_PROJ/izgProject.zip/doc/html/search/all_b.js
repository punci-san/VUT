var searchData=
[
  ['name',['name',['../structMethod.html#aaa3bc473db253cbd522121f15781bd25',1,'Method']]],
  ['nofpoints',['nofPoints',['../structPointBoxData.html#acca7bde471ab3396be16f21efda7c639',1,'PointBoxData::nofPoints()'],['../structPointCircleData.html#a7abecef6dbc69a26cc54066632bee9f0',1,'PointCircleData::nofPoints()'],['../structPointSquareData.html#ae6ea4fe73b1bd8c83ff2de1d6183b841',1,'PointSquareData::nofPoints()']]],
  ['normal',['normal',['../structBunnyVertex.html#aa7f67904a835c896f368dd2e37cc46db',1,'BunnyVertex']]],
  ['normalize_5fvec2',['normalize_Vec2',['../linearAlgebra_8c.html#aef887725c2f4d11256731400b232a1bf',1,'normalize_Vec2(Vec2 *const output, Vec2 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#aef887725c2f4d11256731400b232a1bf',1,'normalize_Vec2(Vec2 *const output, Vec2 const *const input):&#160;linearAlgebra.c']]],
  ['normalize_5fvec3',['normalize_Vec3',['../linearAlgebra_8c.html#a29413d309c1692fac4d63a4fc080903c',1,'normalize_Vec3(Vec3 *const output, Vec3 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a29413d309c1692fac4d63a4fc080903c',1,'normalize_Vec3(Vec3 *const output, Vec3 const *const input):&#160;linearAlgebra.c']]],
  ['normalize_5fvec4',['normalize_Vec4',['../linearAlgebra_8c.html#a8333ef95a3ea4503121bd0f8ec2e5a93',1,'normalize_Vec4(Vec4 *const output, Vec4 const *const input):&#160;linearAlgebra.c'],['../linearAlgebra_8h.html#a8333ef95a3ea4503121bd0f8ec2e5a93',1,'normalize_Vec4(Vec4 *const output, Vec4 const *const input):&#160;linearAlgebra.c']]]
];
