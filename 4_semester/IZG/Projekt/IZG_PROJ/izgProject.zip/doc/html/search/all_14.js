var searchData=
[
  ['width',['width',['../structGPUFramebuffer.html#a6475f75a6d81ac7136b48878ee715e77',1,'GPUFramebuffer']]],
  ['window',['Window',['../structWindow.html',1,'Window'],['../structAppData.html#a6c13a148335a069ffb6751feea3ad398',1,'AppData::window()'],['../structWindow.html#ae39a7755a5a6ab74bcbdbe3e2e206820',1,'Window::window()']]]
];
