var searchData=
[
  ['stack',['Stack',['../structStack.html',1,'']]]
];
