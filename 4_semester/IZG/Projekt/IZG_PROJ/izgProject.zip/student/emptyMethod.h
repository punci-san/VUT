#pragma once

void empty_onInit(void*a);
void empty_onDraw(void*a);
void empty_onExit(void*a);
