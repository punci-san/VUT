#include <QtCore>
#include <QtWidgets>
#include <QObject>


/**
*@author Jaromir Hradil, xhradi15@fit.vutbr.cz
*/


/**
*Class for creating graphic elements of reset button
*/
class resetGraphic
{
  public:
    /**
    *Public method for setting graphic elements of button
    */
   static  void setUpResetButton(QPushButton * restartButton);


};
